from pymongo import MongoClient, ASCENDING, DESCENDING
from config import Config
import os

client = None
db = None

def get_db():
    global client, db
    if db is None:
        client = MongoClient(Config.MONGO_URI)
        db = client[Config.DB_NAME]
        _ensure_indexes()
    return db

def _ensure_indexes():
    """Create indexes for performance."""
    db.citizens.create_index([("email", ASCENDING)], unique=True)
    db.citizens.create_index([("phone", ASCENDING)], unique=True)
    db.officers.create_index([("employee_id", ASCENDING)], unique=True)
    db.officers.create_index([("email", ASCENDING)], unique=True)
    db.complaints.create_index([("complaint_id", ASCENDING)], unique=True)
    db.complaints.create_index([("citizen_id", ASCENDING)])
    db.complaints.create_index([("status", ASCENDING)])
    db.complaints.create_index([("ward", ASCENDING)])
    db.complaints.create_index([("created_at", DESCENDING)])
    db.alerts.create_index([("is_active", ASCENDING)])
    db.service_requests.create_index([("citizen_id", ASCENDING)])
    db.infrastructure_assets.create_index([("ward", ASCENDING)])
    db.audit_logs.create_index([("created_at", DESCENDING)])
