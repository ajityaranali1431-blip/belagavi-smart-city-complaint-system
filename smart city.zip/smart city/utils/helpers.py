import os
import uuid
from datetime import datetime
from config import Config

BELAGAVI_WARDS = [
    "Ward 1 - Camp", "Ward 2 - Shahpur", "Ward 3 - Angol",
    "Ward 4 - Tilakwadi", "Ward 5 - Sadashivnagar", "Ward 6 - Vadgaon",
    "Ward 7 - Sambra", "Ward 8 - Khanapur Road", "Ward 9 - Shivaji Nagar",
    "Ward 10 - Ramtirth Nagar", "Ward 11 - Lingaraj", "Ward 12 - Gandhi Nagar",
    "Ward 13 - Maratha Colony", "Ward 14 - Nehru Nagar", "Ward 15 - Raja Nagar",
    "Ward 16 - Subhas Nagar", "Ward 17 - Bhagyanagar", "Ward 18 - Hanuman Nagar",
    "Ward 19 - Azad Nagar", "Ward 20 - Hindwadi", "Ward 21 - Konnur",
    "Ward 22 - Bogarves", "Ward 23 - Shahu Nagar", "Ward 24 - Rukmini Nagar",
    "Ward 25 - Malmaruti", "Ward 26 - Goaves", "Ward 27 - Kirloskarwadi",
    "Ward 28 - Ainapur", "Ward 29 - Kangrali", "Ward 30 - Udyambag",
    "Ward 31 - Naganur", "Ward 32 - Satti Nagar", "Ward 33 - Belgaum Camp",
    "Ward 34 - Bhairidevarakoppa", "Ward 35 - Kapileshwari", "Ward 36 - Mutnal",
    "Ward 37 - Kasaba", "Ward 38 - Handigund", "Ward 39 - Khade Bazar",
    "Ward 40 - Parvati Nagar", "Ward 41 - Saptapur", "Ward 42 - Dharwad Road",
    "Ward 43 - Belgaum Road", "Ward 44 - Udyog Nagar", "Ward 45 - Samarth Nagar",
    "Ward 46 - Narasimha Nagar", "Ward 47 - Naka", "Ward 48 - Desur",
    "Ward 49 - Macche", "Ward 50 - Kadoli", "Ward 51 - Mugalkhod",
    "Ward 52 - Hebbal", "Ward 53 - Keshwapur", "Ward 54 - Maroli",
    "Ward 55 - Kakati", "Ward 56 - Hirekodi", "Ward 57 - Bailhongal Road",
    "Ward 58 - Yellur"
]

COMPLAINT_CATEGORIES = {
    "Roads & Potholes": ["Pothole", "Road Damage", "Speed Breaker", "Road Encroachment", "Other"],
    "Water Supply": ["No Water Supply", "Low Pressure", "Contaminated Water", "Leakage", "Other"],
    "Streetlights": ["Light Not Working", "Damaged Pole", "Flickering Light", "New Connection Required", "Other"],
    "Garbage & Sanitation": ["Overflowing Bin", "Illegal Dumping", "Sewage Overflow", "Bad Smell", "Other"],
    "Parks & Recreation": ["Broken Equipment", "Overgrown Grass", "Missing Bench", "Vandalism", "Other"],
    "Power Supply": ["No Power", "Voltage Fluctuation", "Fallen Wire", "Meter Issue", "Other"],
    "Drainage": ["Blocked Drain", "Overflowing Drain", "Open Drain", "Flooding", "Other"],
    "Other": ["General Complaint", "Other"]
}

DEPARTMENTS = [
    "Roads & Infrastructure",
    "Water Supply",
    "Power Supply",
    "Sanitation & Garbage",
    "Parks & Recreation",
    "Drainage",
    "Town Planning",
    "Public Health",
    "Administration"
]

def generate_complaint_id():
    now = datetime.utcnow()
    return f"BLG-{now.year}-{str(uuid.uuid4().int)[:6]}"

def allowed_file(filename):
    return "." in filename and \
           filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS

def save_uploaded_file(file, subfolder="complaints"):
    if file and allowed_file(file.filename):
        ext = file.filename.rsplit(".", 1)[1].lower()
        filename = f"{uuid.uuid4().hex}.{ext}"
        upload_path = os.path.join(Config.UPLOAD_FOLDER, subfolder)
        os.makedirs(upload_path, exist_ok=True)
        file.save(os.path.join(upload_path, filename))
        return f"/static/uploads/{subfolder}/{filename}"
    return None

def format_datetime(dt):
    if not dt:
        return "N/A"
    return dt.strftime("%d %b %Y, %I:%M %p")

def time_ago(dt):
    if not dt:
        return "N/A"
    diff = datetime.utcnow() - dt
    if diff.days > 0:
        return f"{diff.days} day{'s' if diff.days > 1 else ''} ago"
    hours = diff.seconds // 3600
    if hours > 0:
        return f"{hours} hour{'s' if hours > 1 else ''} ago"
    minutes = diff.seconds // 60
    return f"{minutes} minute{'s' if minutes > 1 else ''} ago"
