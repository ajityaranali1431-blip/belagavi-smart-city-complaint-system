import bcrypt
from datetime import datetime
from functools import wraps
from flask import session, redirect, url_for, flash
from utils.db import get_db
from bson import ObjectId

def hash_password(plain_password: str) -> str:
    return bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def check_password(plain_password: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain_password.encode("utf-8"), hashed.encode("utf-8"))

def citizen_login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "citizen_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("citizen.login"))
        return f(*args, **kwargs)
    return decorated

def corp_login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "officer_id" not in session:
            flash("Please log in to the Corporation Portal.", "warning")
            return redirect(url_for("corp.login"))
        return f(*args, **kwargs)
    return decorated

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if "officer_id" not in session:
                return redirect(url_for("corp.login"))
            if session.get("officer_role") not in roles:
                flash("Access denied. Insufficient permissions.", "danger")
                return redirect(url_for("corp.dashboard"))
            return f(*args, **kwargs)
        return decorated
    return decorator

def log_action(officer_id, action, details=None):
    db = get_db()
    db.audit_logs.insert_one({
        "officer_id": str(officer_id),
        "action": action,
        "details": details or {},
        "created_at": datetime.utcnow()
    })
