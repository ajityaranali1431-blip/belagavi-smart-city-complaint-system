from utils.db import get_db
from utils.auth import hash_password
from utils.helpers import generate_complaint_id
from datetime import datetime
from bson import ObjectId


# ─── CITIZENS ───────────────────────────────────────────────────────────────

def create_citizen(data: dict):
    db = get_db()
    citizen = {
        "first_name": data["first_name"],
        "last_name": data["last_name"],
        "email": data["email"].lower().strip(),
        "phone": data["phone"].strip(),
        "ward": data["ward"],
        "password_hash": hash_password(data["password"]),
        "is_active": True,
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    result = db.citizens.insert_one(citizen)
    return str(result.inserted_id)

def get_citizen_by_email(email: str):
    db = get_db()
    return db.citizens.find_one({"email": email.lower().strip()})

def get_citizen_by_id(citizen_id: str):
    db = get_db()
    return db.citizens.find_one({"_id": ObjectId(citizen_id)})


# ─── OFFICERS ───────────────────────────────────────────────────────────────

def create_officer(data: dict):
    db = get_db()
    officer = {
        "name": data["name"],
        "email": data["email"].lower().strip(),
        "employee_id": data["employee_id"].upper().strip(),
        "department": data["department"],
        "role": data["role"],  # super_admin | dept_head | field_officer
        "password_hash": hash_password(data["password"]),
        "is_active": True,
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    result = db.officers.insert_one(officer)
    return str(result.inserted_id)

def get_officer_by_employee_id(employee_id: str):
    db = get_db()
    return db.officers.find_one({"employee_id": employee_id.upper().strip()})

def get_officer_by_id(officer_id: str):
    db = get_db()
    return db.officers.find_one({"_id": ObjectId(officer_id)})


# ─── COMPLAINTS ─────────────────────────────────────────────────────────────

def create_complaint(data: dict) -> str:
    db = get_db()
    complaint = {
        "complaint_id": generate_complaint_id(),
        "citizen_id": data["citizen_id"],
        "citizen_name": data.get("citizen_name", ""),
        "category": data["category"],
        "sub_category": data.get("sub_category", ""),
        "title": data["title"],
        "description": data["description"],
        "priority": data.get("priority", "medium"),
        "ward": data["ward"],
        "location_text": data.get("location_text", ""),
        "latitude": data.get("latitude"),
        "longitude": data.get("longitude"),
        "media_urls": data.get("media_urls", []),
        "status": "pending",
        "assigned_to": None,
        "assigned_dept": None,
        "timeline": [{
            "status": "pending",
            "note": "Complaint filed by citizen.",
            "updated_by": "system",
            "timestamp": datetime.utcnow()
        }],
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    result = db.complaints.insert_one(complaint)
    return str(result.inserted_id)

def get_complaints_for_citizen(citizen_id: str, limit=10):
    db = get_db()
    return list(db.complaints.find(
        {"citizen_id": citizen_id},
        sort=[("created_at", -1)],
        limit=limit
    ))

def get_all_complaints(filters=None, page=1, per_page=10):
    db = get_db()
    query = filters or {}
    skip = (page - 1) * per_page
    total = db.complaints.count_documents(query)
    complaints = list(db.complaints.find(query, sort=[("created_at", -1)], skip=skip, limit=per_page))
    return complaints, total

def update_complaint_status(complaint_id: str, status: str, note: str, officer_id: str, assigned_to=None, assigned_dept=None):
    db = get_db()
    update = {
        "$set": {
            "status": status,
            "updated_at": datetime.utcnow()
        },
        "$push": {
            "timeline": {
                "status": status,
                "note": note,
                "updated_by": officer_id,
                "timestamp": datetime.utcnow()
            }
        }
    }
    if assigned_to:
        update["$set"]["assigned_to"] = assigned_to
    if assigned_dept:
        update["$set"]["assigned_dept"] = assigned_dept
    db.complaints.update_one({"complaint_id": complaint_id}, update)


# ─── ALERTS ─────────────────────────────────────────────────────────────────

def create_alert(data: dict) -> str:
    db = get_db()
    alert = {
        "title": data["title"],
        "description": data["description"],
        "alert_type": data.get("alert_type", "info"),  # info | warning | emergency
        "wards": data.get("wards", []),  # empty = all wards
        "is_active": True,
        "created_by": data["created_by"],
        "created_at": datetime.utcnow(),
        "expires_at": data.get("expires_at")
    }
    result = db.alerts.insert_one(alert)
    return str(result.inserted_id)

def get_active_alerts(ward=None):
    db = get_db()
    query = {"is_active": True}
    if ward:
        query["$or"] = [{"wards": []}, {"wards": ward}]
    return list(db.alerts.find(query, sort=[("created_at", -1)]))




def create_service_request(data: dict) -> str:
    db = get_db()
    req = {
        "citizen_id": data["citizen_id"],
        "citizen_name": data.get("citizen_name", ""),
        "service_type": data["service_type"],
        "details": data.get("details", {}),
        "status": "submitted",
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    result = db.service_requests.insert_one(req)
    return str(result.inserted_id)


# ─── DASHBOARD STATS ─────────────────────────────────────────────────────────

def get_corp_dashboard_stats():
    db = get_db()
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    return {
        "total_today": db.complaints.count_documents({"created_at": {"$gte": today_start}}),
        "resolved_today": db.complaints.count_documents({"status": "resolved", "updated_at": {"$gte": today_start}}),
        "pending": db.complaints.count_documents({"status": "pending"}),
        "in_progress": db.complaints.count_documents({"status": "in_progress"}),
        "total_citizens": db.citizens.count_documents({}),
        "active_alerts": db.alerts.count_documents({"is_active": True}),
        "total_complaints": db.complaints.count_documents({}),
        "total_resolved": db.complaints.count_documents({"status": "resolved"}),
    }

def get_complaints_by_category():
    db = get_db()
    pipeline = [
        {"$group": {"_id": "$category", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]
    return list(db.complaints.aggregate(pipeline))

def get_complaints_by_status():
    db = get_db()
    pipeline = [
        {"$group": {"_id": "$status", "count": {"$sum": 1}}}
    ]
    return list(db.complaints.aggregate(pipeline))
