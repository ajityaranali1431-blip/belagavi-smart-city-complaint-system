from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from models.models import (
    get_officer_by_employee_id, get_officer_by_id,
    get_all_complaints, update_complaint_status,
    get_corp_dashboard_stats, get_complaints_by_category,
    get_complaints_by_status, get_active_alerts, create_alert
)
from utils.auth import check_password, corp_login_required, role_required, log_action
from utils.helpers import DEPARTMENTS
from utils.db import get_db
from bson import ObjectId
from datetime import datetime

corp_bp = Blueprint("corp", __name__, url_prefix="/corp")


# ── AUTH ────────────────────────────────────────────────────────────────────

@corp_bp.route("/login", methods=["GET", "POST"])
def login():
    if "officer_id" in session:
        return redirect(url_for("corp.dashboard"))
    if request.method == "POST":
        emp_id = request.form.get("employee_id", "").strip()
        password = request.form.get("password", "")
        officer = get_officer_by_employee_id(emp_id)
        if officer and check_password(password, officer["password_hash"]) and officer.get("is_active"):
            session["officer_id"] = str(officer["_id"])
            session["officer_name"] = officer["name"]
            session["officer_role"] = officer["role"]
            session["officer_dept"] = officer["department"]
            session["officer_emp_id"] = officer["employee_id"]
            log_action(str(officer["_id"]), "login", {"employee_id": emp_id})
            flash(f"Welcome, {officer['name']}!", "success")
            return redirect(url_for("corp.dashboard"))
        flash("Invalid Employee ID or password.", "danger")
    return render_template("corp/login.html", departments=DEPARTMENTS)


@corp_bp.route("/logout")
def logout():
    if "officer_id" in session:
        log_action(session["officer_id"], "logout")
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.index"))


# ── DASHBOARD ───────────────────────────────────────────────────────────────

@corp_bp.route("/dashboard")
@corp_login_required
def dashboard():
    stats = get_corp_dashboard_stats()
    by_category = get_complaints_by_category()
    by_status = get_complaints_by_status()
    recent_complaints, _ = get_all_complaints(page=1, per_page=5)
    active_alerts = get_active_alerts()[:3]
    db = get_db()
    dept_stats = []
    for dept in DEPARTMENTS[:5]:
        total = db.complaints.count_documents({"assigned_dept": dept})
        resolved = db.complaints.count_documents({"assigned_dept": dept, "status": "resolved"})
        rate = round((resolved / total * 100) if total > 0 else 0)
        dept_stats.append({"dept": dept, "total": total, "resolved": resolved, "rate": rate})
    return render_template("corp/dashboard.html",
                           stats=stats,
                           by_category=by_category,
                           by_status=by_status,
                           recent_complaints=recent_complaints,
                           active_alerts=active_alerts,
                           dept_stats=dept_stats,
                           departments=DEPARTMENTS)


# ── COMPLAINTS ──────────────────────────────────────────────────────────────

@corp_bp.route("/complaints")
@corp_login_required
def complaints():
    page = int(request.args.get("page", 1))
    status_filter = request.args.get("status", "")
    ward_filter = request.args.get("ward", "")
    category_filter = request.args.get("category", "")
    search = request.args.get("search", "")
    query = {}
    if status_filter:
        query["status"] = status_filter
    if ward_filter:
        query["ward"] = ward_filter
    if category_filter:
        query["category"] = category_filter
    if search:
        query["$or"] = [
            {"complaint_id": {"$regex": search, "$options": "i"}},
            {"citizen_name": {"$regex": search, "$options": "i"}},
            {"location_text": {"$regex": search, "$options": "i"}}
        ]
    complaints_list, total = get_all_complaints(filters=query, page=page, per_page=10)
    from utils.helpers import BELAGAVI_WARDS, COMPLAINT_CATEGORIES
    return render_template("corp/complaints.html",
                           complaints=complaints_list,
                           total=total,
                           page=page,
                           per_page=10,
                           status_filter=status_filter,
                           ward_filter=ward_filter,
                           category_filter=category_filter,
                           search=search,
                           wards=BELAGAVI_WARDS,
                           categories=list(COMPLAINT_CATEGORIES.keys()),
                           departments=DEPARTMENTS)


@corp_bp.route("/complaints/<complaint_id>/update", methods=["POST"])
@corp_login_required
def update_complaint(complaint_id):
    new_status = request.form.get("status")
    note = request.form.get("note", "Status updated by officer.")
    assigned_to = request.form.get("assigned_to")
    assigned_dept = request.form.get("assigned_dept")
    update_complaint_status(complaint_id, new_status, note, session["officer_id"], assigned_to, assigned_dept)
    log_action(session["officer_id"], "complaint_update", {
        "complaint_id": complaint_id, "new_status": new_status
    })
    flash("Complaint updated successfully.", "success")
    return redirect(url_for("corp.complaints"))


# ── ALERTS ──────────────────────────────────────────────────────────────────

@corp_bp.route("/alerts")
@corp_login_required
def alerts():
    active_alerts = get_active_alerts()
    return render_template("corp/alerts.html", alerts=active_alerts)


@corp_bp.route("/alerts/create", methods=["GET", "POST"])
@corp_login_required
def create_alert_view():
    from utils.helpers import BELAGAVI_WARDS
    if request.method == "POST":
        wards_selected = request.form.getlist("wards")
        data = {
            "title": request.form.get("title", "").strip(),
            "description": request.form.get("description", "").strip(),
            "alert_type": request.form.get("alert_type", "info"),
            "wards": wards_selected,
            "created_by": session["officer_id"]
        }
        create_alert(data)
        log_action(session["officer_id"], "alert_created", {"title": data["title"]})
        flash("Alert broadcast successfully!", "success")
        return redirect(url_for("corp.alerts"))
    return render_template("corp/create_alert.html", wards=BELAGAVI_WARDS)


@corp_bp.route("/alerts/<alert_id>/deactivate", methods=["POST"])
@corp_login_required
def deactivate_alert(alert_id):
    db = get_db()
    db.alerts.update_one({"_id": ObjectId(alert_id)}, {"$set": {"is_active": False}})
    log_action(session["officer_id"], "alert_deactivated", {"alert_id": alert_id})
    flash("Alert deactivated.", "info")
    return redirect(url_for("corp.alerts"))





# ── ANALYTICS ────────────────────────────────────────────────────────────────

@corp_bp.route("/analytics")
@corp_login_required
def analytics():
    stats = get_corp_dashboard_stats()
    by_category = get_complaints_by_category()
    by_status = get_complaints_by_status()
    db = get_db()
    
    dept_stats = []
    for dept in DEPARTMENTS[:5]:
        total = db.complaints.count_documents({"assigned_dept": dept})
        resolved = db.complaints.count_documents({"assigned_dept": dept, "status": "resolved"})
        rate = round((resolved / total * 100) if total > 0 else 0)
        dept_stats.append({"dept": dept, "total": total, "resolved": resolved, "rate": rate})
        
    from utils.helpers import BELAGAVI_WARDS
    ward_stats = []
    for ward in BELAGAVI_WARDS[:10]:
        count = db.complaints.count_documents({"ward": ward})
        if count > 0:
            ward_stats.append({"ward": ward, "count": count})
    ward_stats.sort(key=lambda x: x["count"], reverse=True)
    return render_template("corp/analytics.html",
                           stats=stats,
                           by_category=by_category,
                           by_status=by_status,
                           ward_stats=ward_stats,
                           dept_stats=dept_stats)


# ── API: JSON data for charts ─────────────────────────────────────────────────

@corp_bp.route("/api/stats")
@corp_login_required
def api_stats():
    return jsonify(get_corp_dashboard_stats())

@corp_bp.route("/api/chart/category")
@corp_login_required
def api_chart_category():
    data = get_complaints_by_category()
    return jsonify([{"label": d["_id"], "value": d["count"]} for d in data])

@corp_bp.route("/api/chart/status")
@corp_login_required
def api_chart_status():
    data = get_complaints_by_status()
    return jsonify([{"label": d["_id"], "value": d["count"]} for d in data])
