from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from models.models import (
    create_citizen, get_citizen_by_email, get_citizen_by_id,
    get_complaints_for_citizen, create_complaint, get_active_alerts
)
from utils.auth import check_password, citizen_login_required
from utils.helpers import BELAGAVI_WARDS, COMPLAINT_CATEGORIES, save_uploaded_file
from datetime import datetime

citizen_bp = Blueprint("citizen", __name__, url_prefix="/citizen")


# ── AUTH ────────────────────────────────────────────────────────────────────

@citizen_bp.route("/login", methods=["GET", "POST"])
def login():
    if "citizen_id" in session:
        return redirect(url_for("citizen.dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        citizen = get_citizen_by_email(email)
        if citizen and check_password(password, citizen["password_hash"]):
            session["citizen_id"] = str(citizen["_id"])
            session["citizen_name"] = f"{citizen['first_name']} {citizen['last_name']}"
            session["citizen_ward"] = citizen["ward"]
            flash(f"Welcome back, {citizen['first_name']}!", "success")
            return redirect(url_for("citizen.dashboard"))
        flash("Invalid email or password. Please try again.", "danger")
    return render_template("citizen/login.html", wards=BELAGAVI_WARDS)


@citizen_bp.route("/register", methods=["GET", "POST"])
def register():
    if "citizen_id" in session:
        return redirect(url_for("citizen.dashboard"))
    if request.method == "POST":
        data = {
            "first_name": request.form.get("first_name", "").strip(),
            "last_name": request.form.get("last_name", "").strip(),
            "email": request.form.get("email", "").strip(),
            "phone": request.form.get("phone", "").strip(),
            "ward": request.form.get("ward", ""),
            "password": request.form.get("password", "")
        }
        confirm = request.form.get("confirm_password", "")
        if data["password"] != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("citizen/login.html", wards=BELAGAVI_WARDS, tab="register")
        if not all([data["first_name"], data["email"], data["phone"], data["ward"], data["password"]]):
            flash("All fields are required.", "danger")
            return render_template("citizen/login.html", wards=BELAGAVI_WARDS, tab="register")
        try:
            create_citizen(data)
            flash("Registration successful! Please log in.", "success")
            return redirect(url_for("citizen.login"))
        except Exception as e:
            flash("Email or phone already registered. Please log in.", "danger")
    return render_template("citizen/login.html", wards=BELAGAVI_WARDS, tab="register")


@citizen_bp.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.index"))


# ── DASHBOARD ───────────────────────────────────────────────────────────────

@citizen_bp.route("/dashboard")
@citizen_login_required
def dashboard():
    citizen = get_citizen_by_id(session["citizen_id"])
    recent_complaints = get_complaints_for_citizen(session["citizen_id"], limit=5)
    alerts = get_active_alerts(ward=session.get("citizen_ward"))[:3]
    return render_template("citizen/dashboard.html",
                           citizen=citizen,
                           recent_complaints=recent_complaints,
                           alerts=alerts)


# ── COMPLAINTS ──────────────────────────────────────────────────────────────

@citizen_bp.route("/complaints")
@citizen_login_required
def complaints():
    all_complaints = get_complaints_for_citizen(session["citizen_id"], limit=50)
    return render_template("citizen/complaints.html", complaints=all_complaints)


@citizen_bp.route("/complaints/new", methods=["GET", "POST"])
@citizen_login_required
def file_complaint():
    if request.method == "POST":
        media_urls = []
        if "media" in request.files:
            for f in request.files.getlist("media"):
                url = save_uploaded_file(f, subfolder="complaints")
                if url:
                    media_urls.append(url)
        citizen = get_citizen_by_id(session["citizen_id"])
        data = {
            "citizen_id": session["citizen_id"],
            "citizen_name": session.get("citizen_name", ""),
            "category": request.form.get("category", ""),
            "sub_category": request.form.get("sub_category", ""),
            "title": request.form.get("title", "").strip(),
            "description": request.form.get("description", "").strip(),
            "priority": request.form.get("priority", "medium"),
            "ward": request.form.get("ward", session.get("citizen_ward", "")),
            "location_text": request.form.get("location_text", "").strip(),
            "media_urls": media_urls
        }
        try:
            create_complaint(data)
            flash("Complaint filed successfully! You can track its status in My Complaints.", "success")
            return redirect(url_for("citizen.complaints"))
        except Exception as e:
            flash(f"Error filing complaint: {str(e)}", "danger")
    return render_template("citizen/file_complaint.html",
                           categories=COMPLAINT_CATEGORIES,
                           wards=BELAGAVI_WARDS,
                           citizen_ward=session.get("citizen_ward", ""))


# ── ALERTS ──────────────────────────────────────────────────────────────────

@citizen_bp.route("/alerts")
@citizen_login_required
def alerts():
    active_alerts = get_active_alerts(ward=session.get("citizen_ward"))
    return render_template("citizen/alerts.html", alerts=active_alerts)


# ── PROFILE ─────────────────────────────────────────────────────────────────

@citizen_bp.route("/profile")
@citizen_login_required
def profile():
    citizen = get_citizen_by_id(session["citizen_id"])
    return render_template("citizen/profile.html", citizen=citizen)


# ── API: subcategories ───────────────────────────────────────────────────────

@citizen_bp.route("/api/subcategories/<category>")
def get_subcategories(category):
    from utils.helpers import COMPLAINT_CATEGORIES
    return jsonify(COMPLAINT_CATEGORIES.get(category, []))
