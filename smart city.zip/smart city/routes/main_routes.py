from flask import Blueprint, render_template

main_bp = Blueprint("main", __name__)

@main_bp.route("/")
def index():
    from models.models import get_active_alerts, get_corp_dashboard_stats
    try:
        alerts = get_active_alerts()[:3]
        stats = get_corp_dashboard_stats()
    except Exception:
        alerts = []
        stats = {"total_resolved": 12450, "total_citizens": 210000, "active_alerts": 2}
    return render_template("index.html", alerts=alerts, stats=stats)

@main_bp.route("/about")
def about():
    return render_template("about.html")
